export type Weather = {
  main: {
    temp: number;
  };
};
